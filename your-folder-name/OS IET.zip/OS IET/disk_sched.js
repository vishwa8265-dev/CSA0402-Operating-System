// Disk Scheduling Algorithms for UniCore OS

class DiskScheduler {
    static getPresetData() {
        return {
            totalCylinders: 200,
            initialHead: 53,
            requests: [98, 183, 37, 122, 14, 124, 65, 67, 15, 130, 199, 143]
        };
    }

    // FCFS Disk Scheduling
    static runFCFS(initialHead, requests) {
        let path = [initialHead, ...requests];
        let steps = [];
        let totalMovement = 0;

        for (let i = 0; i < path.length - 1; i++) {
            let from = path[i];
            let to = path[i + 1];
            let seek = Math.abs(to - from);
            totalMovement += seek;
            steps.push({ step: i + 1, from, to, seek, accumulated: totalMovement });
        }

        return { path, steps, totalMovement, avgSeek: (totalMovement / requests.length).toFixed(2) };
    }

    // SSTF Disk Scheduling
    static runSSTF(initialHead, inputRequests) {
        let reqs = [...inputRequests];
        let current = initialHead;
        let path = [initialHead];
        let steps = [];
        let totalMovement = 0;
        let stepCount = 1;

        while (reqs.length > 0) {
            let nearest = reqs.reduce((prev, curr) => Math.abs(curr - current) < Math.abs(prev - current) ? curr : prev, reqs[0]);
            let seek = Math.abs(nearest - current);
            totalMovement += seek;
            path.push(nearest);
            steps.push({ step: stepCount++, from: current, to: nearest, seek, accumulated: totalMovement });
            current = nearest;
            reqs = reqs.filter(r => r !== nearest);
        }

        return { path, steps, totalMovement, avgSeek: (totalMovement / inputRequests.length).toFixed(2) };
    }

    // SCAN Disk Scheduling (Direction: UP to max cylinder 199, then reversed)
    static runSCAN(initialHead, requests, totalCylinders = 200, direction = "up") {
        let sortedReqs = [...requests].sort((a, b) => a - b);
        let path = [initialHead];
        let steps = [];
        let totalMovement = 0;
        let stepCount = 1;

        let upper = sortedReqs.filter(r => r >= initialHead);
        let lower = sortedReqs.filter(r => r < initialHead);

        let sequence = [];
        if (direction === "up") {
            sequence = [...upper];
            if (!sequence.includes(totalCylinders - 1)) {
                sequence.push(totalCylinders - 1);
            }
            sequence = [...sequence, ...lower.reverse()];
        } else {
            sequence = [...lower.reverse()];
            if (!sequence.includes(0)) {
                sequence.push(0);
            }
            sequence = [...sequence, ...upper];
        }

        let current = initialHead;
        for (let target of sequence) {
            let seek = Math.abs(target - current);
            totalMovement += seek;
            path.push(target);
            steps.push({ step: stepCount++, from: current, to: target, seek, accumulated: totalMovement });
            current = target;
        }

        return { path, steps, totalMovement, avgSeek: (totalMovement / requests.length).toFixed(2) };
    }

    // C-SCAN Disk Scheduling (Direction: UP to max cylinder 199, wrap to 0, then UP)
    static runCSCAN(initialHead, requests, totalCylinders = 200) {
        let sortedReqs = [...requests].sort((a, b) => a - b);
        let path = [initialHead];
        let steps = [];
        let totalMovement = 0;
        let stepCount = 1;

        let upper = sortedReqs.filter(r => r >= initialHead);
        let lower = sortedReqs.filter(r => r < initialHead);

        let sequence = [...upper];
        if (sequence[sequence.length - 1] !== totalCylinders - 1) {
            sequence.push(totalCylinders - 1);
        }
        sequence.push(0);
        sequence = [...sequence, ...lower];

        let current = initialHead;
        for (let target of sequence) {
            let seek = Math.abs(target - current);
            totalMovement += seek;
            path.push(target);
            steps.push({ step: stepCount++, from: current, to: target, seek, accumulated: totalMovement });
            current = target;
        }

        return { path, steps, totalMovement, avgSeek: (totalMovement / requests.length).toFixed(2) };
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = DiskScheduler;
}

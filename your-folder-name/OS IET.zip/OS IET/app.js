// Application Controller for UniCore OS Web App

document.addEventListener('DOMContentLoaded', () => {
    // Initialize initial views
    runCPUSimulation('priority');
    renderBankersMatrices();
    runBankersSafety();
    runPageReplacement(3);
    runDiskSimulation('scan');
});

// Tab Switcher
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));

    document.getElementById(tabId).classList.remove('hidden');
    document.getElementById('nav-' + tabId).classList.add('active');

    // Re-render SVG on tab switch if disk tab
    if (tabId === 'tab-disk') {
        runDiskSimulation(currentDiskAlg || 'scan');
    }
}

// ----------------------------------------------------
// CPU SCHEDULING MODULE
// ----------------------------------------------------
let currentCPUAlg = 'priority';

function runCPUSimulation(algType) {
    currentCPUAlg = algType;
    let procs = CPUScheduler.getPresetProcesses();
    let res;

    let titleEl = document.getElementById('cpu-gantt-title');
    let badgeEl = document.getElementById('cpu-algorithm-badge');

    if (algType === 'priority') {
        res = CPUScheduler.runPriorityNP(procs);
        titleEl.innerHTML = `<i data-feather="bar-chart-2" class="text-sky-400"></i> Priority Scheduling (Non-Preemptive) Gantt Chart`;
        badgeEl.className = 'text-xs px-3 py-1 bg-sky-500/20 text-sky-400 rounded-full font-semibold';
        badgeEl.innerText = 'Priority NP';
    } else if (algType === 'rr') {
        res = CPUScheduler.runRoundRobin(procs, 4);
        titleEl.innerHTML = `<i data-feather="bar-chart-2" class="text-indigo-400"></i> Round Robin (quantum = 4) Gantt Chart`;
        badgeEl.className = 'text-xs px-3 py-1 bg-indigo-500/20 text-indigo-400 rounded-full font-semibold';
        badgeEl.innerText = 'Round Robin q=4';
    } else {
        res = CPUScheduler.runHybridScheduler(procs, 4);
        titleEl.innerHTML = `<i data-feather="bar-chart-2" class="text-emerald-400"></i> Hybrid Two-Tier Queue Gantt Chart`;
        badgeEl.className = 'text-xs px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-full font-semibold';
        badgeEl.innerText = 'Hybrid Scheduler';
    }

    renderGanttChart(res.gantt);
    renderCPUMetrics(res.metrics);
    feather.replace();
}

function renderGanttChart(gantt) {
    let container = document.getElementById('cpu-gantt-container');
    let timeline = document.getElementById('cpu-gantt-timeline');
    container.innerHTML = '';
    timeline.innerHTML = '';

    let totalDuration = gantt[gantt.length - 1].finish;

    gantt.forEach((slice, idx) => {
        let duration = slice.finish - slice.start;
        let pct = (duration / totalDuration) * 100;

        let bar = document.createElement('div');
        bar.className = `gantt-bar bg-${slice.classType}`;
        bar.style.width = `${pct}%`;
        bar.title = `${slice.id} (${slice.name}): ${slice.start} -> ${slice.finish}`;

        bar.innerHTML = `
            <span>${slice.id}</span>
            <span class="time-label">${slice.start}-${slice.finish}</span>
        `;
        container.appendChild(bar);
    });

    timeline.innerHTML = `<span>Time 0</span><span>Time ${totalDuration}</span>`;
}

function renderCPUMetrics(metrics) {
    let tbody = document.getElementById('cpu-metrics-table-body');
    tbody.innerHTML = '';

    metrics.forEach(m => {
        let tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="p-3 font-bold text-sky-400">${m.id}</td>
            <td class="p-3 font-medium">${m.name}</td>
            <td class="p-3 text-slate-400">${m.arrival}</td>
            <td class="p-3 text-slate-400">${m.burst}</td>
            <td class="p-3 text-slate-400">${m.priority}</td>
            <td class="p-3 text-slate-300 font-mono">${m.start}</td>
            <td class="p-3 text-slate-300 font-mono">${m.finish}</td>
            <td class="p-3 text-slate-300 font-mono">${m.waiting}</td>
            <td class="p-3 text-slate-300 font-mono">${m.turnaround}</td>
            <td class="p-3 font-mono font-bold ${m.classType === 'exam' ? 'text-sky-400' : 'text-slate-300'}">${m.response}</td>
        `;
        tbody.appendChild(tr);
    });

    let avgs = CPUScheduler.calculateAverages(metrics);
    document.getElementById('metric-avg-wait').innerText = avgs.avgWait;
    document.getElementById('metric-avg-turn').innerText = avgs.avgTurn;
    document.getElementById('metric-avg-resp').innerText = avgs.avgResp;
    document.getElementById('metric-exam-resp').innerText = avgs.examAvgResp;
    document.getElementById('metric-backup-resp').innerText = avgs.backupAvgResp;
}


// ----------------------------------------------------
// BANKER'S ALGORITHM MODULE
// ----------------------------------------------------
function renderBankersMatrices() {
    let data = BankersAlgorithm.getPresetData();
    let need = BankersAlgorithm.calculateNeed(data.allocation, data.max, data.processes, data.resources);
    let { available } = BankersAlgorithm.calculateAvailable(data.total, data.allocation, data.processes, data.resources);

    // Update Available summary cards
    data.resources.forEach(r => {
        document.getElementById(`avail-${r}`).innerText = available[r];
    });

    let tbody = document.getElementById('bankers-matrix-body');
    tbody.innerHTML = '';

    data.processes.forEach(p => {
        let tr = document.createElement('tr');
        let allocHtml = data.resources.map(r => `<td class="p-2 font-mono text-sky-300 bg-sky-950/20">${data.allocation[p][r]}</td>`).join('');
        let maxHtml = data.resources.map(r => `<td class="p-2 font-mono text-indigo-300 bg-indigo-950/20">${data.max[p][r]}</td>`).join('');
        let needHtml = data.resources.map(r => `<td class="p-2 font-mono text-amber-300 bg-amber-950/20">${need[p][r]}</td>`).join('');

        tr.innerHTML = `
            <td class="p-2 text-left font-bold text-slate-200">${p} <span class="text-xs text-slate-500">(${data.processNames[p]})</span></td>
            ${allocHtml}
            ${maxHtml}
            ${needHtml}
        `;
        tbody.appendChild(tr);
    });
}

function runBankersSafety() {
    let data = BankersAlgorithm.getPresetData();
    let safety = BankersAlgorithm.checkSafety(data.total, data.allocation, data.max, data.processes, data.resources);

    let badge = document.getElementById('bankers-status-badge');
    let seqDisplay = document.getElementById('bankers-safe-seq-display');
    let logBox = document.getElementById('bankers-trace-log');

    if (safety.isSafe) {
        badge.className = 'step-badge step-badge-safe';
        badge.innerText = 'SAFE STATE';
        seqDisplay.innerText = `Safe Sequence: < ${safety.safeSeq.join(', ')} >`;

        logBox.innerHTML = '';
        safety.stepsTrace.forEach((st, idx) => {
            let workStr = Object.entries(st.workAfter).map(([k, v]) => `${k}:${v}`).join(' ');
            let item = document.createElement('div');
            item.className = 'p-2 bg-slate-900 rounded border border-slate-800 flex justify-between items-center';
            item.innerHTML = `
                <span>Step ${idx + 1}: Process <strong class="text-sky-400">${st.process}</strong> finished</span>
                <span class="text-emerald-400 font-semibold">Work = { ${workStr} }</span>
            `;
            logBox.appendChild(item);
        });
    } else {
        badge.className = 'step-badge step-badge-unsafe';
        badge.innerText = 'UNSAFE STATE';
        seqDisplay.innerText = `No valid safe sequence found! System is in UNSAFE state.`;
    }
}

function testBankersRequest() {
    let pid = document.getElementById('req-pid').value;
    let req = {
        DB: parseInt(document.getElementById('req-DB').value),
        FL: parseInt(document.getElementById('req-FL').value),
        PR: parseInt(document.getElementById('req-PR').value),
        BK: parseInt(document.getElementById('req-BK').value)
    };

    let data = BankersAlgorithm.getPresetData();
    let evalRes = BankersAlgorithm.requestResources(pid, req, data.total, data.allocation, data.max, data.processes, data.resources);

    let resultBox = document.getElementById('request-eval-result');

    if (evalRes.granted) {
        resultBox.className = 'p-3 bg-emerald-950/40 rounded-xl border border-emerald-800 text-xs text-emerald-300';
        resultBox.innerHTML = `
            <div class="font-bold flex items-center gap-2"><i data-feather="check-circle"></i> ${evalRes.reason}</div>
            <div class="mt-1 font-mono">Safe Sequence: &lt; ${evalRes.safeSeq.join(', ')} &gt;</div>
        `;
    } else {
        resultBox.className = 'p-3 bg-rose-950/40 rounded-xl border border-rose-800 text-xs text-rose-300';
        resultBox.innerHTML = `
            <div class="font-bold flex items-center gap-2"><i data-feather="x-circle"></i> Request DENIED</div>
            <div class="mt-1">${evalRes.reason}</div>
        `;
    }
    feather.replace();
}


// ----------------------------------------------------
// MEMORY MANAGEMENT MODULE
// ----------------------------------------------------
function runPageReplacement(framesCount = 3) {
    let ref = MemoryManager.getPresetData().refString;

    let fifoRes = MemoryManager.runFIFO(ref, framesCount);
    let lruRes = MemoryManager.runLRU(ref, framesCount);
    let optRes = MemoryManager.runOptimal(ref, framesCount);

    document.getElementById('fifo-fault-badge').innerText = `${fifoRes.faults} Faults (${framesCount} frames)`;
    document.getElementById('lru-fault-badge').innerText = `${lruRes.faults} Faults (${framesCount} frames)`;
    document.getElementById('opt-fault-badge').innerText = `${optRes.faults} Faults (${framesCount} frames)`;

    renderTraceBox('fifo-trace-box', fifoRes.trace);
    renderTraceBox('lru-trace-box', lruRes.trace);
    renderTraceBox('opt-trace-box', optRes.trace);
}

function renderTraceBox(boxId, trace) {
    let box = document.getElementById(boxId);
    box.innerHTML = '';

    trace.forEach(t => {
        let div = document.createElement('div');
        div.className = `flex justify-between items-center px-2 py-0.5 rounded ${t.isFault ? 'bg-rose-950/30 text-rose-300' : 'text-slate-400'}`;
        div.innerHTML = `
            <span>Ref ${t.page}</span>
            <span>Frames: [${t.frames.join(', ')}]</span>
            <span class="font-bold">${t.isFault ? 'FAULT' : 'HIT'}</span>
        `;
        box.appendChild(div);
    });
}

function runBeladyDemo() {
    let res = MemoryManager.runBeladyCheck();
    let tbody = document.getElementById('belady-table-body');
    tbody.innerHTML = '';

    let trFifo = document.createElement('tr');
    trFifo.innerHTML = `
        <td class="p-2 text-left font-bold text-amber-400">FIFO</td>
        <td class="p-2">${res.fifoResults[2]} faults</td>
        <td class="p-2">${res.fifoResults[3]} faults</td>
        <td class="p-2 bg-rose-950/60 text-rose-400 font-extrabold">${res.fifoResults[4]} FAULTS ⚠️ (Belady Anomaly!)</td>
        <td class="p-2">${res.fifoResults[5]} faults</td>
        <td class="p-2">${res.fifoResults[6]} faults</td>
    `;
    tbody.appendChild(trFifo);

    let trLru = document.createElement('tr');
    trLru.innerHTML = `
        <td class="p-2 text-left font-bold text-purple-400">LRU</td>
        <td class="p-2">${res.lruResults[2]} faults</td>
        <td class="p-2">${res.lruResults[3]} faults</td>
        <td class="p-2 text-emerald-400">${res.lruResults[4]} faults</td>
        <td class="p-2">${res.lruResults[5]} faults</td>
        <td class="p-2">${res.lruResults[6]} faults</td>
    `;
    tbody.appendChild(trLru);
}


// ----------------------------------------------------
// DISK SCHEDULING MODULE
// ----------------------------------------------------
let currentDiskAlg = 'scan';

function runDiskSimulation(algType) {
    currentDiskAlg = algType;
    let data = DiskScheduler.getPresetData();
    let res;

    let titleEl = document.getElementById('disk-alg-title');
    let totalEl = document.getElementById('disk-total-move');

    if (algType === 'fcfs') {
        res = DiskScheduler.runFCFS(data.initialHead, data.requests);
        titleEl.innerText = 'FCFS (First Come First Served)';
    } else if (algType === 'sstf') {
        res = DiskScheduler.runSSTF(data.initialHead, data.requests);
        titleEl.innerText = 'SSTF (Shortest Seek Time First)';
    } else if (algType === 'scan') {
        res = DiskScheduler.runSCAN(data.initialHead, data.requests, data.totalCylinders, 'up');
        titleEl.innerText = 'SCAN (Elevator Algorithm)';
    } else {
        res = DiskScheduler.runCSCAN(data.initialHead, data.requests, data.totalCylinders);
        titleEl.innerText = 'C-SCAN (Circular SCAN)';
    }

    totalEl.innerText = `${res.totalMovement} Cylinders (Avg ${res.avgSeek})`;

    renderSVGDiskGraph(res.path, data.totalCylinders);
}

function renderSVGDiskGraph(path, totalCylinders = 200) {
    let svg = document.getElementById('disk-svg-graph');
    svg.innerHTML = '';

    let width = svg.clientWidth || 800;
    let height = svg.clientHeight || 280;
    let padding = 40;

    let points = path.map((cyl, idx) => {
        let x = padding + (idx / (path.length - 1)) * (width - 2 * padding);
        let y = padding + (cyl / (totalCylinders - 1)) * (height - 2 * padding);
        return { x, y, cyl, step: idx };
    });

    // Draw background grid lines
    for (let c = 0; c <= totalCylinders; c += 50) {
        let y = padding + (c / (totalCylinders - 1)) * (height - 2 * padding);
        let line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', padding);
        line.setAttribute('y1', y);
        line.setAttribute('x2', width - padding);
        line.setAttribute('y2', y);
        line.setAttribute('stroke', '#334155');
        line.setAttribute('stroke-dasharray', '3 3');
        svg.appendChild(line);

        let text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', 10);
        text.setAttribute('y', y + 4);
        text.setAttribute('fill', '#64748b');
        text.setAttribute('font-size', '10');
        text.textContent = `Cyl ${c}`;
        svg.appendChild(text);
    }

    // Draw path line
    let pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
    let pathEl = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    pathEl.setAttribute('d', pathD);
    pathEl.setAttribute('fill', 'none');
    pathEl.setAttribute('stroke', '#38bdf8');
    pathEl.setAttribute('stroke-width', '3');
    pathEl.className = 'seek-line';
    svg.appendChild(pathEl);

    // Draw point circles with cylinder text labels
    points.forEach(p => {
        let circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', p.x);
        circle.setAttribute('cy', p.y);
        circle.setAttribute('r', '5');
        circle.className = 'seek-point';

        let title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
        title.textContent = `Step ${p.step}: Cylinder ${p.cyl}`;
        circle.appendChild(title);
        svg.appendChild(circle);

        let label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('x', p.x);
        label.setAttribute('y', p.y - 10);
        label.setAttribute('text-anchor', 'middle');
        label.setAttribute('fill', '#f8fafc');
        label.setAttribute('font-size', '10');
        label.setAttribute('font-weight', 'bold');
        label.textContent = p.cyl;
        svg.appendChild(label);
    });
}

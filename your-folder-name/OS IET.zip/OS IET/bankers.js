// Banker's Algorithm for Deadlock Avoidance in UniCore OS

class BankersAlgorithm {
    static getPresetData() {
        return {
            resources: ['DB', 'FL', 'PR', 'BK'],
            resourceNames: {
                DB: 'Database Connections (total 9)',
                FL: 'File Locks (total 6)',
                PR: 'Print/Report Slots (total 5)',
                BK: 'Backup/IO Channels (total 9)'
            },
            total: { DB: 9, FL: 6, PR: 5, BK: 9 },
            processes: ['P0', 'P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7'],
            processNames: {
                P0: 'Exam-submit',
                P1: 'Exam-fetch',
                P2: 'Library-index',
                P3: 'Exam-autosave',
                P4: 'Backup',
                P5: 'Research-job',
                P6: 'IoT-monitor',
                P7: 'Backup-verify'
            },
            allocation: {
                P0: { DB: 2, FL: 0, PR: 0, BK: 1 },
                P1: { DB: 1, FL: 1, PR: 0, BK: 0 },
                P2: { DB: 2, FL: 1, PR: 1, BK: 2 },
                P3: { DB: 0, FL: 1, PR: 1, BK: 1 },
                P4: { DB: 1, FL: 0, PR: 1, BK: 0 },
                P5: { DB: 0, FL: 1, PR: 0, BK: 2 },
                P6: { DB: 1, FL: 1, PR: 1, BK: 1 },
                P7: { DB: 0, FL: 0, PR: 0, BK: 1 }
            },
            max: {
                P0: { DB: 5, FL: 1, PR: 1, BK: 2 },
                P1: { DB: 3, FL: 2, PR: 1, BK: 1 },
                P2: { DB: 6, FL: 2, PR: 2, BK: 3 },
                P3: { DB: 2, FL: 2, PR: 2, BK: 2 },
                P4: { DB: 4, FL: 1, PR: 2, BK: 1 },
                P5: { DB: 1, FL: 2, PR: 1, BK: 3 },
                P6: { DB: 3, FL: 2, PR: 2, BK: 2 },
                P7: { DB: 2, FL: 1, PR: 1, BK: 2 }
            }
        };
    }

    static calculateNeed(allocation, max, processes, resources) {
        let need = {};
        processes.forEach(p => {
            need[p] = {};
            resources.forEach(r => {
                need[p][r] = max[p][r] - allocation[p][r];
            });
        });
        return need;
    }

    static calculateAvailable(total, allocation, processes, resources) {
        let allocatedSum = {};
        resources.forEach(r => {
            allocatedSum[r] = processes.reduce((sum, p) => sum + allocation[p][r], 0);
        });

        let available = {};
        resources.forEach(r => {
            available[r] = total[r] - allocatedSum[r];
        });

        return { available, allocatedSum };
    }

    // Safety Algorithm Execution
    static checkSafety(total, allocation, max, processes, resources) {
        let need = this.calculateNeed(allocation, max, processes, resources);
        let { available } = this.calculateAvailable(total, allocation, processes, resources);

        let work = { ...available };
        let finish = {};
        processes.forEach(p => finish[p] = false);

        let safeSeq = [];
        let stepsTrace = [];

        while (true) {
            let foundProcess = false;

            for (let p of processes) {
                if (!finish[p]) {
                    let canProceed = resources.every(r => need[p][r] <= work[r]);
                    if (canProceed) {
                        // Process can complete: release its allocated resources to work
                        resources.forEach(r => work[r] += allocation[p][r]);
                        finish[p] = true;
                        safeSeq.push(p);
                        stepsTrace.push({
                            process: p,
                            workAfter: { ...work },
                            need: { ...need[p] },
                            allocation: { ...allocation[p] }
                        });
                        foundProcess = true;
                        break;
                    }
                }
            }

            if (!foundProcess) break;
        }

        let isSafe = processes.every(p => finish[p]);

        return {
            isSafe,
            safeSeq,
            stepsTrace,
            need,
            available
        };
    }

    // Evaluate an incremental Resource Request by a process
    static requestResources(pid, request, total, allocation, max, processes, resources) {
        let need = this.calculateNeed(allocation, max, processes, resources);
        let { available } = this.calculateAvailable(total, allocation, processes, resources);

        // Precondition 1: Request <= Need[pid]
        let reqLeNeed = resources.every(r => request[r] <= need[pid][r]);
        // Precondition 2: Request <= Available
        let reqLeAvail = resources.every(r => request[r] <= available[r]);

        if (!reqLeNeed) {
            return {
                granted: false,
                reason: `Request exceeds declared Maximum Need for process ${pid}.`,
                details: { reqLeNeed, reqLeAvail }
            };
        }

        if (!reqLeAvail) {
            return {
                granted: false,
                reason: `Insufficient physically available resources to satisfy request immediately.`,
                details: { reqLeNeed, reqLeAvail }
            };
        }

        // Tentative Allocation
        let tentAllocation = JSON.parse(JSON.stringify(allocation));
        resources.forEach(r => {
            tentAllocation[pid][r] += request[r];
        });

        // Tentative Safety Check
        let safetyRes = this.checkSafety(total, tentAllocation, max, processes, resources);

        if (safetyRes.isSafe) {
            return {
                granted: true,
                tentativeAvailable: safetyRes.available,
                safeSeq: safetyRes.safeSeq,
                stepsTrace: safetyRes.stepsTrace,
                reason: `Request GRANTED safely. System remains in a SAFE state.`
            };
        } else {
            return {
                granted: false,
                tentativeAvailable: safetyRes.available,
                reason: `Request DENIED by Banker's Algorithm. Granting request leads to an UNSAFE state with possible circular-wait deadlock! Process ${pid} must WAIT.`,
                details: { reqLeNeed, reqLeAvail }
            };
        }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = BankersAlgorithm;
}

// Memory Management & Page Replacement Simulator for UniCore OS

class MemoryManager {
    static getPresetData() {
        return {
            physicalRamGB: 16,
            pageSizeKB: 4,
            processSizeMB: 64,
            refString: [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0],
            beladyRefString: [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]
        };
    }

    static calculateAddressSpace(ramGB = 16, pageSizeKB = 4, processMB = 64) {
        let ramBytes = ramGB * Math.pow(1024, 3);
        let pageBytes = pageSizeKB * 1024;
        let processBytes = processMB * Math.pow(1024, 2);

        let totalFrames = Math.floor(ramBytes / pageBytes);
        let processPages = Math.floor(processBytes / pageBytes);

        let offsetBits = Math.log2(pageBytes);
        let pageBits = Math.log2(processPages);
        let frameBits = Math.log2(totalFrames);

        let pteSizeBytes = 4; // Typical 4-byte PTE
        let singleLevelTableBytes = processPages * pteSizeBytes;
        let singleLevelTableKB = (singleLevelTableBytes / 1024).toFixed(1);

        return {
            totalFrames,
            processPages,
            offsetBits,
            pageBits,
            frameBits: Math.ceil(frameBits),
            singleLevelTableBytes,
            singleLevelTableKB
        };
    }

    // FIFO Page Replacement
    static runFIFO(refString, numFrames) {
        let frames = [];
        let faults = 0;
        let trace = [];

        for (let idx = 0; idx < refString.length; idx++) {
            let page = refString[idx];
            let isFault = false;

            if (!frames.includes(page)) {
                faults++;
                isFault = true;
                if (frames.length >= numFrames) {
                    frames.shift(); // Evict oldest
                }
                frames.push(page);
            }

            trace.push({
                step: idx + 1,
                page: page,
                frames: [...frames],
                isFault: isFault
            });
        }

        return { faults, trace };
    }

    // LRU Page Replacement
    static runLRU(refString, numFrames) {
        let frames = [];
        let faults = 0;
        let trace = [];
        let recency = {};

        for (let idx = 0; idx < refString.length; idx++) {
            let page = refString[idx];
            let isFault = false;

            if (!frames.includes(page)) {
                faults++;
                isFault = true;
                if (frames.length >= numFrames) {
                    // Evict page with smallest recency index
                    let lruPage = frames.reduce((oldest, p) => recency[p] < recency[oldest] ? p : oldest, frames[0]);
                    frames = frames.filter(p => p !== lruPage);
                }
                frames.push(page);
            }

            recency[page] = idx;

            trace.push({
                step: idx + 1,
                page: page,
                frames: [...frames],
                isFault: isFault
            });
        }

        return { faults, trace };
    }

    // Optimal Page Replacement
    static runOptimal(refString, numFrames) {
        let frames = [];
        let faults = 0;
        let trace = [];

        for (let idx = 0; idx < refString.length; idx++) {
            let page = refString[idx];
            let isFault = false;

            if (!frames.includes(page)) {
                faults++;
                isFault = true;
                if (frames.length >= numFrames) {
                    let future = refString.slice(idx + 1);
                    let victim = frames[0];
                    let maxDistance = -1;

                    for (let p of frames) {
                        let nextUse = future.indexOf(p);
                        if (nextUse === -1) {
                            victim = p;
                            break; // Not used again in future
                        }
                        if (nextUse > maxDistance) {
                            maxDistance = nextUse;
                            victim = p;
                        }
                    }

                    frames = frames.filter(p => p !== victim);
                }
                frames.push(page);
            }

            trace.push({
                step: idx + 1,
                page: page,
                frames: [...frames],
                isFault: isFault
            });
        }

        return { faults, trace };
    }

    // Run Belady's Anomaly Test across frame counts (2 to 6)
    static runBeladyCheck(beladyRefString = [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]) {
        let fifoResults = {};
        let lruResults = {};

        for (let f = 2; f <= 6; f++) {
            fifoResults[f] = this.runFIFO(beladyRefString, f).faults;
            lruResults[f] = this.runLRU(beladyRefString, f).faults;
        }

        return { fifoResults, lruResults, refString: beladyRefString };
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = MemoryManager;
}

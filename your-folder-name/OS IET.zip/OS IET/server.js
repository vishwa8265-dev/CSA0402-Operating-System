const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname)));

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', system: 'UniCore OS Resource Orchestration Web App' });
});

app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`🚀 UniCore OS Web App Running at http://localhost:${PORT}`);
    console.log(`====================================================`);
});

// CPU Scheduling Algorithms for UniCore OS

class CPUScheduler {
    static getPresetProcesses() {
        return [
            { id: "P0", arrival: 0, burst: 4, priority: 1, name: "Exam-submit", classType: "exam" },
            { id: "P1", arrival: 1, burst: 3, priority: 1, name: "Exam-fetch", classType: "exam" },
            { id: "P2", arrival: 2, burst: 8, priority: 3, name: "Library-index", classType: "library" },
            { id: "P3", arrival: 3, burst: 2, priority: 1, name: "Exam-autosave", classType: "exam" },
            { id: "P4", arrival: 4, burst: 10, priority: 4, name: "Backup", classType: "backup" },
            { id: "P5", arrival: 5, burst: 6, priority: 2, name: "Research-job", classType: "research" },
            { id: "P6", arrival: 6, burst: 5, priority: 2, name: "IoT-monitor", classType: "iot" },
            { id: "P7", arrival: 7, burst: 9, priority: 4, name: "Backup-verify", classType: "backup" }
        ];
    }

    // Priority Scheduling (Non-Preemptive, 1 = Highest Priority)
    static runPriorityNP(inputProcs) {
        let procs = JSON.parse(JSON.stringify(inputProcs));
        let remaining = [...procs];
        let currentTime = 0;
        let gantt = [];
        let metrics = {};

        while (remaining.length > 0) {
            let ready = remaining.filter(p => p.arrival <= currentTime);
            if (ready.length === 0) {
                let nextArrival = Math.min(...remaining.map(p => p.arrival));
                currentTime = nextArrival;
                ready = remaining.filter(p => p.arrival <= currentTime);
            }

            // Pick candidate with lowest numerical priority value; break tie by arrival
            ready.sort((a, b) => {
                if (a.priority !== b.priority) return a.priority - b.priority;
                return a.arrival - b.arrival;
            });

            let chosen = ready[0];
            let start = Math.max(currentTime, chosen.arrival);
            let finish = start + chosen.burst;

            gantt.push({
                id: chosen.id,
                name: chosen.name,
                start: start,
                finish: finish,
                classType: chosen.classType
            });

            metrics[chosen.id] = {
                id: chosen.id,
                name: chosen.name,
                arrival: chosen.arrival,
                burst: chosen.burst,
                priority: chosen.priority,
                start: start,
                finish: finish,
                waiting: start - chosen.arrival,
                turnaround: finish - chosen.arrival,
                response: start - chosen.arrival,
                classType: chosen.classType
            };

            currentTime = finish;
            remaining = remaining.filter(p => p.id !== chosen.id);
        }

        return { gantt, metrics: Object.values(metrics) };
    }

    // Round Robin (Quantum = 4)
    static runRoundRobin(inputProcs, quantum = 4) {
        let procs = JSON.parse(JSON.stringify(inputProcs)).sort((a, b) => a.arrival - b.arrival);
        let remainingBT = {};
        let arrivalMap = {};
        let firstResponse = {};
        let finishTime = {};
        let classTypeMap = {};
        let nameMap = {};
        let priorityMap = {};

        procs.forEach(p => {
            remainingBT[p.id] = p.burst;
            arrivalMap[p.id] = p.arrival;
            classTypeMap[p.id] = p.classType;
            nameMap[p.id] = p.name;
            priorityMap[p.id] = p.priority;
        });

        let queue = [];
        let currentTime = 0;
        let idx = 0;
        let n = procs.length;
        let gantt = [];

        // Push processes arrived at t=0
        while (idx < n && procs[idx].arrival <= currentTime) {
            queue.push(procs[idx].id);
            idx++;
        }

        if (queue.length === 0 && idx < n) {
            currentTime = procs[idx].arrival;
            while (idx < n && procs[idx].arrival <= currentTime) {
                queue.push(procs[idx].id);
                idx++;
            }
        }

        while (queue.length > 0) {
            let pid = queue.shift();

            if (!(pid in firstResponse)) {
                firstResponse[pid] = currentTime;
            }

            let runDuration = Math.min(quantum, remainingBT[pid]);
            let start = currentTime;
            currentTime += runDuration;
            remainingBT[pid] -= runDuration;

            gantt.push({
                id: pid,
                name: nameMap[pid],
                start: start,
                finish: currentTime,
                classType: classTypeMap[pid]
            });

            // Enqueue new arrivals BEFORE re-adding current process if it needs more time
            while (idx < n && procs[idx].arrival <= currentTime) {
                queue.push(procs[idx].id);
                idx++;
            }

            if (remainingBT[pid] > 0) {
                queue.push(pid);
            } else {
                finishTime[pid] = currentTime;
            }

            if (queue.length === 0 && idx < n) {
                currentTime = Math.max(currentTime, procs[idx].arrival);
                while (idx < n && procs[idx].arrival <= currentTime) {
                    queue.push(procs[idx].id);
                    idx++;
                }
            }
        }

        let metrics = procs.map(p => {
            let pid = p.id;
            let fin = finishTime[pid];
            let arr = arrivalMap[pid];
            let bur = p.burst;
            return {
                id: pid,
                name: p.name,
                arrival: arr,
                burst: bur,
                priority: priorityMap[pid],
                start: firstResponse[pid],
                finish: fin,
                waiting: fin - arr - bur,
                turnaround: fin - arr,
                response: firstResponse[pid] - arr,
                classType: classTypeMap[pid]
            };
        });

        return { gantt, metrics };
    }

    // Two-level Hybrid Scheduler (High priority queue = Exam/Priority-NP, Low priority = RR q=4)
    static runHybridScheduler(inputProcs, quantum = 4) {
        let procs = JSON.parse(JSON.stringify(inputProcs));
        let examProcs = procs.filter(p => p.priority === 1);
        let bgProcs = procs.filter(p => p.priority > 1);

        // High priority exam jobs run first by Priority NP
        let highRes = this.runPriorityNP(examProcs);
        let maxHighFinish = highRes.gantt.length > 0 ? Math.max(...highRes.gantt.map(g => g.finish)) : 0;

        // Shift background process arrival times if needed or run with queue precedence
        let adjustedBgProcs = bgProcs.map(p => ({
            ...p,
            arrival: Math.max(p.arrival, maxHighFinish)
        }));

        let lowRes = this.runRoundRobin(adjustedBgProcs, quantum);

        let gantt = [...highRes.gantt, ...lowRes.gantt];
        let metrics = [...highRes.metrics, ...lowRes.metrics].sort((a, b) => parseInt(a.id.replace('P','')) - parseInt(b.id.replace('P','')));

        return { gantt, metrics };
    }

    // Helper to compute summary averages
    static calculateAverages(metrics) {
        let n = metrics.length;
        let avgWait = metrics.reduce((acc, m) => acc + m.waiting, 0) / n;
        let avgTurn = metrics.reduce((acc, m) => acc + m.turnaround, 0) / n;
        let avgResp = metrics.reduce((acc, m) => acc + m.response, 0) / n;

        let examGroup = metrics.filter(m => m.id === "P0" || m.id === "P1" || m.id === "P3" || m.classType === "exam");
        let backupGroup = metrics.filter(m => m.id === "P4" || m.id === "P7" || m.classType === "backup");

        let examAvgResp = examGroup.length > 0 ? examGroup.reduce((acc, m) => acc + m.response, 0) / examGroup.length : 0;
        let backupAvgResp = backupGroup.length > 0 ? backupGroup.reduce((acc, m) => acc + m.response, 0) / backupGroup.length : 0;

        return {
            avgWait: avgWait.toFixed(2),
            avgTurn: avgTurn.toFixed(2),
            avgResp: avgResp.toFixed(2),
            examAvgResp: examAvgResp.toFixed(2),
            backupAvgResp: backupAvgResp.toFixed(2)
        };
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = CPUScheduler;
}
